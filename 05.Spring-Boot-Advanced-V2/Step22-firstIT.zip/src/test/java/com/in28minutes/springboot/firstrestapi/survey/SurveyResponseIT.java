package com.in28minutes.springboot.firstrestapi.survey;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class SurveyResponseIT {

	// 
	/*
	 
  "id": "Question1",
  "description": "Most Popular Cloud Platform Today",
  "options": [
    "AWS",
    "Azure",
    "Google Cloud",
    "Oracle Cloud"
  ],
  "correctAnswer": "AWS"
} 
	 
	 */
	
	//{"id":"Question1","description":"Most Popular Cloud Platform Today","options":["AWS","Azure","Google Cloud","Oracle Cloud"],"correctAnswer":"AWS"}

	
	@Autowired
	TestRestTemplate template;
	
	@Test
	void retrieveSpecificSurveyQuestion_basicScenario() throws JSONException {
		String url = "/surveys/Survey1/questions/Question1";
		ResponseEntity<String> response = template.getForEntity(url, String.class);
		System.out.println(response.getBody());
		System.out.println(response.getHeaders());
		//String expectedResponse="{\"id\":\"Question1\",\"description\":\"Most Popular Cloud Platform Today\",\"options\":[\"AWS\",\"Azure\",\"Google Cloud\",\"Oracle Cloud\"],\"correctAnswer\":\"AWS\"}";
		String expectedResponse = "{id:Question1, correctAnswer:AWS, \"description\":\"Most Popular Cloud Platform Today\"}"; 
		
		JSONAssert.assertEquals(expectedResponse, response.getBody(), false);
	}
}
